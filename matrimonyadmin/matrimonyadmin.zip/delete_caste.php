<?php
include("../include/connect.php");
$id=$_REQUEST['id'];
mysql_query("delete from caste where id='$id'");
echo "<script type='text/javascript'>alert('Caste deleted Successfully');window.location.href='view_caste.php'</script>;";
?>