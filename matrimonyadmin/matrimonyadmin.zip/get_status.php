<?php
include("../include/connect.php");
$h=$_GET['h'];
$selsql="SELECT * from register where id='$h'";
$selresult=mysql_query($selsql) or die(mysql_error());
$row=mysql_fetch_array($selresult);
$name=$row['name'];
$sts1=$row['status'];
$clientemail=$row['email']; 
$clientmobile=$row['mobile'];

if($sts1==1)
{
mysql_query("update register set status='0' where id='$h'");
}
else if($sts1==0)
{
$a=rand(100000,999999);
$b='HM';
$username=$b.$a;
$s=rand(10000,99999);	
mysql_query("update register set status='1' where id='$h'");	
mysql_query("update register set username='$username',password='$s' where id='$h'");		
echo $username;
}
?>