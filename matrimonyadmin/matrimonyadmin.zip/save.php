<?php
include("../include/connect.php");
$command=$_POST['command'];
if($command=="change_psw")
{

    $c_pass=$_POST['c_pass'];	
	$n_pass=$_POST['n_pass'];
	$user_id=$_POST['user_id'];
	mysql_query("update admin set password='$n_pass' where id='$user_id' and password='$c_pass'");
	echo "<script type='text/javascript'>alert('Your password Changed Successfully');window.location.href='change_pass.php';</script>";
}
else if($command=="change_password")
{
$tab_id=$_POST['tab_id'];
$n_pass=$_POST['n_pass'];

mysql_query("update admin set password='$n_pass' where id='$tab_id'");
echo "<script type='text/javascript'>alert('Password Changed!');window.location.href='change_password.php';</script>";
}
else if($command=="news")
{

    $news_heading=mysql_real_escape_string($_POST['news_heading']);	
	$descrip=mysql_real_escape_string($_POST['descrip']);
	$news_id=$_POST['news_id'];
	$aa=mysql_query("select * from news");
	$count_aa=mysql_num_rows($aa);
	if($count_aa>0)
	{
		mysql_query("update news set news_heading='$news_heading',descrip='$descrip' where id='$news_id'");
	}
	else
	{
	
	mysql_query("insert into news (news_heading,descrip) values('$news_heading','$descrip')");	
		
	}
		
	
	echo "<script type='text/javascript'>alert('News and Events updated Successfully');window.location.href='news.php';</script>";
}
elseif($command=="education")
{

        $education=$_POST['education'];	
	mysql_query("insert into education(education) values('$education')");
	echo "<script type='text/javascript'>alert('Education Added Successfully');window.location.href='view_education.php';</script>";
}

elseif($command=="edit_education")
{

        $education=$_POST['education'];	
	$c_id=$_POST['c_id'];	
	mysql_query("update education set education='$education' where id='$c_id'");
	echo "<script type='text/javascript'>alert('Education Name Edited Successfully');window.location.href='view_education.php';</script>";
}
else if($command=="horo")
{
$random_no=rand(10000000,99999999);
$userid=$_POST['userid'];

$file=$_FILES['image']['name'];
	if(!empty($file))
	{	
	$target_path = "horo/";
	$uploaded_files=$random_no."_".$_FILES['image']['name'];
	move_uploaded_file($_FILES['image']['tmp_name'], $target_path .$random_no."_".$_FILES['image']['name']);
	}
//echo "update register set horo='$uploaded_files' where id='$userid'";exit;
mysql_query("update register set horo='$uploaded_files' where id='$userid'");
	echo "<script type='text/javascript'>alert('Horoscope Uploaded Successfully');window.location.href='home.php';</script>";
}

elseif($command=="caste")
{

    $caste=$_POST['caste'];	
	mysql_query("insert into caste (caste) values('$caste')");
	echo "<script type='text/javascript'>alert('Caste Added Successfully');window.location.href='view_caste.php';</script>";
}

elseif($command=="edit_caste")
{

    $caste=$_POST['caste'];	
	$c_id=$_POST['c_id'];	
	mysql_query("update caste set caste='$caste' where id='$c_id'");
	echo "<script type='text/javascript'>alert('Caste Name Edited Successfully');window.location.href='view_caste.php';</script>";
}

elseif($command=="subcaste")
{

    $caste=$_POST['caste'];	
	 $subcaste=$_POST['subcaste'];	
	mysql_query("insert into subcaste (caste,subcaste) values('$caste','$subcaste')");
	echo "<script type='text/javascript'>alert('Sub-Caste Added Successfully');window.location.href='view_subcaste.php';</script>";
}

elseif($command=="edit_subcaste")
{

    $caste=$_POST['caste'];	
	 $subcaste=$_POST['subcaste'];
	 	$c_id=$_POST['c_id'];		
		mysql_query("update subcaste set caste='$caste',subcaste='$subcaste' where id='$c_id'");
	echo "<script type='text/javascript'>alert('Sub-Caste Name Edited Successfully');window.location.href='view_subcaste.php';</script>";
}

elseif($command=="education")
{

    $education=$_POST['education'];	
	mysql_query("insert into education (education) values('$education')");
	echo "<script type='text/javascript'>alert('Education Details Added Successfully');window.location.href='add_education.php';</script>";
}
elseif($command=="compose")
{

    $caste=$_POST['caste'];	
	$subject=$_POST['subject'];	
	$message=mysql_real_escape_string($_POST['message']);	
	
	mysql_query("insert into message (caste,subject,message) values('$caste','$subject','$message')");
	echo "<script type='text/javascript'>alert('Message Sent');window.location.href='compose_message.php';</script>";
}
?>