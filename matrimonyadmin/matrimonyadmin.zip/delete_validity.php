<?php
include("../include/connect.php");
$userid=$_REQUEST['userid'];
mysql_query("update register set today_date='',valid_for='',valid_status='',valid_string='' where id='$userid'");
echo "<script type='text/javascript'>alert('Validity deleted Successfully');window.close();</script>;";
?>