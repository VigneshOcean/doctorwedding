<?php
include("../include/connect.php");
$userid=$_POST['userid'];
$today_date=$_POST['today_date'];
$marriage_status=$_POST['marriage_status'];


mysql_query("update register set enquiry_date='$today_date',enquiry_status='$marriage_status' where id='$userid'")or die(mysql_error());



echo "<script type='text/javascript'>window.close();</script>";

?>
