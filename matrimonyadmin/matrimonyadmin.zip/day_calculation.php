<?php
include("../include/connect.php");
error_reporting(0);
ini_set('post_max_size', '10M');
ini_set('max_input_time', 300);
ini_set('max_execution_time', 15000);

session_start();
$id=$_SESSION['id'];
if(!isset($_SESSION['id']))
{
echo "<script type=text/javascript>window.location='index.php?err'</script>";
}
else
{
function get_age($birth_date)
{
return floor((time() - strtotime($birth_date))/31556926);
}
$mani1=mysql_query("select * from  register where dob!=''");
while($row_mani1=mysql_fetch_array($mani1))
{
$d_id=$row_mani1['id'];
$ddb=$row_mani1['dob'];
$ddb1=explode('/',$ddb);
$agge1=$ddb1[2].'-'.$ddb1[1].'-'.$ddb1[0];
$aa=get_age($agge1);
mysql_query("update register set age='$aa' where id='$d_id'");
//echo $aa;
}
echo "<script type=text/javascript>alert('Age Uploaded');window.location='home.php';</script>";
}
?>