function setCookie(key, val) {
	var mainDomain = window.location.hostname.replace('www', '');
	var date = new Date();
    date.setTime(date.getTime() + (0.5 * 24 * 60 * 60 * 1000));
    expires = "; expires=" + date.toGMTString();
	var cookie = document.cookie = key + "=" + val + expires + ";domain="+ mainDomain +";path=/";
}

function getCookie(data) {
    var data_set = data + "=";
    var ca = document.cookie.split(';');
    for(var i=0;i < ca.length;i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1,c.length);
        if (c.indexOf(data_set) == 0) return c.substring(data_set.length,c.length);
    }
    return "";
}

function deleteCookie(data) {
    var mainDomain = window.location.hostname.replace('www', '');
    document.cookie = data +'=; Path=/; domain='+ mainDomain +';Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
}
 
function getLang(){
    var currentLang = getCookie('_lang');
    if(currentLang){
        return currentLang;
    } else {
        setCookie("_lang", "cn");
        return getCookie('_lang');
    }
}

function convertLang(lang){
    if(lang[getLang()]){
        return lang[getLang()];
    }
    
    return lang['cn'];
}

function deleteUniqueCookies() {
    var mainDomain = window.location.hostname.replace('www', '');
    var cookies = document.cookie.split(';');
    var uniqueCookies = [];
    for(var i = 0; i < cookies.length; i++) {
        if(cookies[i].includes('rcmd-') || cookies[i].includes('optl-')) {
            var cookieName = cookies[i].split('=')[0];
            document.cookie = cookieName + '=; Path=/; domain='+ mainDomain +';Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
        }
    }  
}