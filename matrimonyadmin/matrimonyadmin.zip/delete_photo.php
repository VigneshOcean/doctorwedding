<?php
include("../include/connect.php");
$userid=$_REQUEST['userid'];
$photo_name=$_REQUEST['photo_name'];
$photo_no=$_REQUEST['photo_no'];
$picture2='../profile/';
$picture=$picture2.$photo_name;
unlink($picture);
if($photo_no==1)
{
mysql_query("update register set uploadedfile='' where id='$userid' ");
}
if($photo_no==2)
{
mysql_query("update register set second_upload='' where id='$userid' ");
}

echo "<script type='text/javascript'>alert('Profile Picture deleted');window.location='edit.php?userid=$userid';</script>";
?>