<?php
include("../include/connect.php");
$id=$_REQUEST['id'];
mysql_query("delete from subcaste where id='$id'");
echo "<script type='text/javascript'>alert('Subcaste deleted Successfully');window.location.href='view_subcaste.php'</script>;";
?>